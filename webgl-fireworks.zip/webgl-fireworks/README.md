# webgl fireworks

A Pen created on CodePen.io. Original URL: [https://codepen.io/palx/pen/YzgyRRP](https://codepen.io/palx/pen/YzgyRRP).

you know what's better than fireworks?
WEBGL FIREWORKS